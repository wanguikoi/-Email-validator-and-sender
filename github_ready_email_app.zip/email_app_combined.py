
import streamlit as st
import smtplib
import dns.resolver
import socket
import csv
import time
from io import StringIO
from concurrent.futures import ThreadPoolExecutor
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import datetime

st.set_page_config(page_title="Email Validator + Sender", layout="wide")
st.title("📧 Email Validator + Batch Email Sender")

def validate_email(email, from_email="noreply@example.com"):
    domain = email.split('@')[-1]
    try:
        records = dns.resolver.resolve(domain, 'MX')
        mx_record = str(records[0].exchange)
    except Exception:
        return email, "Invalid domain or DNS error"
    try:
        server = smtplib.SMTP(timeout=10)
        server.connect(mx_record)
        server.helo(socket.gethostname())
        server.mail(from_email)
        code, _ = server.rcpt(email)
        server.quit()
        if code in [250, 251]:
            return email, "Valid"
        else:
            return email, f"Invalid (code {code})"
    except Exception as e:
        return email, f"Error: {str(e)}"

# Step 1: Upload email list
st.header("Step 1: Upload Email List")
uploaded_file = st.file_uploader("Upload .txt or .csv file", type=["txt", "csv"])
emails = []

if uploaded_file:
    content = uploaded_file.read().decode("utf-8")
    emails = [line.strip() for line in content.splitlines() if "@" in line]
    st.success(f"Loaded {len(emails)} email(s)")

# Step 2: Validate emails
st.header("Step 2: Validate Emails (Optional)")
if emails:
    if st.button("Validate Emails"):
        valid_results = []
        with ThreadPoolExecutor(max_workers=10) as executor:
            futures = [executor.submit(validate_email, email) for email in emails]
            for i, future in enumerate(futures):
                email, status = future.result()
                st.write(f"{i+1}. {email} — {status}")
                if "Valid" in status:
                    valid_results.append(email)
        st.success(f"Validation complete. {len(valid_results)} valid emails found.")
        emails = valid_results

# Step 3: Compose or Upload Email
st.header("Step 3: Compose or Upload Email")
send_option = st.radio("How would you like to write your email?", ["Compose in app", "Upload .txt or .html"])

subject = st.text_input("Subject")
body = ""

if send_option == "Compose in app":
    body = st.text_area("Email Body", height=200)
else:
    uploaded_email = st.file_uploader("Upload Email Content (.txt or .html)", type=["txt", "html"])
    if uploaded_email:
        body = uploaded_email.read().decode("utf-8")
        st.success("Email content loaded.")

# Step 4: SMTP Settings
st.header("Step 4: SMTP Settings")
smtp_host = st.text_input("SMTP Host")
smtp_port = st.number_input("SMTP Port", value=587)
smtp_user = st.text_input("SMTP Username")
smtp_pass = st.text_input("SMTP Password", type="password")
batch_size = st.slider("Emails per minute", 1, 100, 30)

# Step 5: Start Sending
st.header("Step 5: Send Emails in Batches")
if st.button("Start Sending") and emails and subject and body and smtp_host and smtp_user and smtp_pass:
    st.info("Sending started... please wait.")
    sent_log = []

    server = smtplib.SMTP(smtp_host, smtp_port)
    server.starttls()
    server.login(smtp_user, smtp_pass)

    for i, email in enumerate(emails):
        try:
            msg = MIMEMultipart()
            msg["From"] = smtp_user
            msg["To"] = email
            msg["Subject"] = subject
            msg.attach(MIMEText(body, "html" if body.strip().startswith("<") else "plain"))
            server.sendmail(smtp_user, email, msg.as_string())
            status = "Sent"
        except Exception as e:
            status = f"Failed: {str(e)}"

        sent_log.append({
            "Email": email,
            "Status": status,
            "Time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })

        st.write(f"{i+1}/{len(emails)} - {email} — {status}")
        if (i + 1) % batch_size == 0:
            st.info("Sleeping 60 seconds to respect batch limit...")
            time.sleep(60)

    server.quit()

    log_output = StringIO()
    writer = csv.DictWriter(log_output, fieldnames=["Email", "Status", "Time"])
    writer.writeheader()
    writer.writerows(sent_log)

    st.download_button("📥 Download Log", log_output.getvalue(), file_name="email_send_log.csv", mime="text/csv")
